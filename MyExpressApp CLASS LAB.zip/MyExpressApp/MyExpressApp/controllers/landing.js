exports.get_landing = (req, res, next) => {
    res.render('landing', { title: 'Express from Kupershtein with Controllers' });
}

exports.submit_lead = function (req, res, next) {
    console.log("lead_name:", req.body.lead_name);
    console.log("lead_email:", req.body.lead_email);
    res.redirect('/');
    const models = require('../models');
    exports.get_landing = (req, res, next) =>
        res.render('landing', { title: 'Express from Kupershtein with Controllers' });
    exports.submit_lead = (req, res, next) => {
        return models.Lead.create({
            email: req.body.lead_email,
            name: req.body.lead_name,
            id: '1'
        }).then(lead => {
            res.redirect('/leads');
        })
    }
}

exports.show_leads = (req, res, next) => {
    models.Lead.findAll().then(leads => {
        res.render('landing', {title: 'Express from Kupershtein with Controllers', leads: leads});
    })
}