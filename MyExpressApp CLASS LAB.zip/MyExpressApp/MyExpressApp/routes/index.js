var express = require('express');
var router = express.Router();

/* GET home page. */
let index = require('../controllers/landing');
router.get('/', index.get_landing);
router.post('/', index.submit_lead);

module.exports = router;